package com.example.appy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Login_form extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_form);

        this.setTitle("Log In");
    }

    public void sign_up_click(View view) {
        startActivity(new Intent(Login_form.this,Signup_form.class));
    }
}